ozone <- read.csv("C:/Users/ustb/Downloads/daily_44201_2014.csv")
ozone

# **Read in your data**
names(ozone) <- make.names(names(ozone))

# **Check the packaging**
nrow(ozone)
ncol(ozone)

# **Run str**
str(ozone)
# **Look at the top and the bottom of your data**
head(ozone[, c(6:7, 10)])
tail(ozone[, c(6:7, 10)])

## asssigment
head(ozone[5, c(6:7, 10)])
tail(ozone[7, c(6:7, 10)])

head(ozone[300, c(2:9, 15)])
tail(ozone[1000, c(12:18, 3)])

# **Check your “n”s**

table(ozone$Time.Local)
install.packages("dplyr")
library(dplyr)
library(dplyr)

# Filtering and selecting the desired columns
filtered_data <- filter(ozone, Time.Local == "13:14") %>% 
  select(State.Name, County.Name, Date.Local, Time.Local, Sample.Measurement)

# Checking unique state names
unique_states <- unique(ozone$State.Name)

unique(ozone$State.Name)



