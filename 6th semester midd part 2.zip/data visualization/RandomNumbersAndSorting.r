# Set the seed for reproducibility (optional)
set.seed(123)  # Change this value for different random sequences

# Generate 10 random integers between 1 and 100
random_numbers <- sample(1:100, size = 10, replace = TRUE)

# Sort the random numbers in descending order
sorted_numbers <- sort(random_numbers, decreasing = TRUE)

# Print the sorted random numbers
print(sorted_numbers)
