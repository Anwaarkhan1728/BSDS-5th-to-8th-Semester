# Set the working directory (replace "path/to/your/file.csv" with the actual path)
# setwd("path/to/your/file.csv")

# Load the data from the CSV file
data <- read.csv("D:/6th semester/midd cours/data visualization/breaking_bad.csv", header = TRUE)
print(data)

# Get basic information about the data
str(data)  # View data structure and variable types

# Get dimensions of the data
dim(data)  # Number of rows and columns

# Summarize the data
summary(data)  # Provides basic statistics for numeric variables

# Check for missing values
summary(apply(data, 2, is.na))  # 2 means apply on columns and Count of missing values in each column 

# Explore specific variables
head(data, n = 10)  # View the first few rows
tail(data)  # View the last few rows
#describe(data)
# Descriptive statistics for specific variables
#describe(data$variable_name)  # Replace "variable_name" with the actual variable name

# Explore data types and convert if necessary
sapply(data, class)  # Check data types of each variable

# This script provides a starting point. You can explore further:

# Filter data based on conditions
subset(data, Duration_mins>50)  # Replace "condition" with your filtering criteria

# Create visualizations (histograms, boxplots, etc.)
hist(data$Duration_mins, col="red")  # Replace "variable_name" with the actual variable name
pie(data$Title, col="green")
# Analyze relationships between variables
cor(data$Rating_IMDB, data$Duration_mins)  # Correlation matrix for numeric variables

# Remember to replace "file.csv" and "variable_name" with your actual file path and variable names
